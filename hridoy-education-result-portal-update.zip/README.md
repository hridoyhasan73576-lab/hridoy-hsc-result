# Hridoy Education Result Portal

A free, responsive, English-language helper website for Bangladesh public examination results.

## Included categories
SSC, HSC, Dakhil, Alim, SSC Vocational, HSC/BM/Vocational, JSC/JDC (archived), and PSC/Ebtedayee (archived; availability varies).

## Important limitation
The website currently redirects users to the relevant official result service. It does not automatically fetch results. A genuine automatic result display requires an authorized API or official data feed and permission. It does not bypass CAPTCHA or other verification.

## Update your existing GitHub Pages site
1. Download the ZIP and extract it.
2. In your GitHub repository, open `index.html`.
3. Tap the pencil (Edit) icon, select all old code, and replace it with the new `index.html` contents; OR use Add file → Upload files and upload the new `index.html`, then confirm replacing it.
4. Commit changes to `main`.
5. GitHub Pages will publish the update automatically, usually within a few minutes.

Official board result portal: https://educationboardresults.gov.bd/v2/home
Primary education authority: https://www.dpe.gov.bd/
